package main;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import javagames.util.*;
import javagames.Vectors.*;
import javagames.Sprites.*;

public class FinalProject extends SimpleFramework {

	private Vector2f mousePosition;
	private IslandMap background = new IslandMap("IslandMap.png");
	private boolean getReverse = false;
	private boolean renderHitboxes = false;
	private float count;
	
	//Sets all of the initial variables which define the canvas space
	public FinalProject() {
		appBackground = Color.GREEN;
		appBorder = Color.BLACK;
		appFont = new Font("Courier New", Font.PLAIN, 14);
		appBorderScale = 1f;
		appFPSColor = Color.BLACK;
		
		//Starting canvas size 
		appWidth = 1280;
		appHeight = 720;
		
		appMaintainRatio = true;
		appSleep = 10L;
		appTitle = "Final Project";
		
		//Aspect ratio 
		appWorldWidth = 16.0f;
		appWorldHeight = 9.0f;
	}
	@Override
	protected void initialize() {
		super.initialize();
		background.setColor(Color.RED);
		
		//Background Hitboxes
	}

	@Override
	protected void processInput(float delta) {
		super.processInput(delta);
	}

	@Override
	protected void updateObjects(float delta) {
		super.updateObjects(delta);
	}

	@Override
	protected void render(Graphics g) {
		super.render(g);
		Matrix3x3f worldViewport = getViewportTransform();
		
		//renders background, then everything else
		background.renderBackground(g, canvas.getWidth(), canvas.getHeight());
		
		//only renders hitbox if b was pressed
		if(renderHitboxes == true){
			background.renderHitboxes(g, worldViewport);
		}
	}
	
	private void disableCursor() {
	      Toolkit tk = Toolkit.getDefaultToolkit();
	      Image image = tk.createImage( "" );
	      Point point = new Point( 0, 0 );
	      String name = "CanBeAnything";
	      Cursor cursor = tk.createCustomCursor( image, point, name );
	      setCursor( cursor );
	   }

	@Override
	protected void terminate() {
		super.terminate();
	}

	public static void main(String[] args) {
		launchApp(new FinalProject());
	}
}